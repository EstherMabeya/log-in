<?php
session_start();
if (!isset($_SESSION['user_id'])) {
  header("Location: index.html");
  exit;
}
echo "<h2>Welcome to your dashboard!</h2>";
echo "<a href='logout.php'>Logout</a>";
?>
