<?php
session_start();
$_SESSION = [];
session_destroy();
setcookie("auth", "", time() - 3600); // Expire cookie
header("Location: index.html");
exit;
?>
