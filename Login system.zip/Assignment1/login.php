<?php
session_start();
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = $_POST['email'];
  $password = $_POST['password'];

  // Prepared statement to prevent SQL injection
  $stmt = $pdo->prepare("SELECT id, password FROM users WHERE email = ?");
  $stmt->execute([$email]);
  $user = $stmt->fetch();

  if ($user && password_verify($password, $user['password'])) {
    // Set secure session
    session_regenerate_id(true);
    $_SESSION['user_id'] = $user['id'];

    // Set secure, HTTP-only cookie
    setcookie("auth", session_id(), [
      'expires' => time() + 3600,
      'path' => '/',
      'secure' => true, // HTTPS only
      'httponly' => true, // Not accessible by JavaScript
      'samesite' => 'Strict'
    ]);

    header("Location: dashboard.php");
    exit;
  } else {
    echo "Invalid credentials";
  }
}
?>
